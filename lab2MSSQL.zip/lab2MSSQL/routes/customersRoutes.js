const express = require('express');
const router = express.Router();
const customersController = require('../controllers/customersController.js');
router
.route('/')
.get(customersController.getCustomers)
.post(customersController.createNewCustomers);
router
.route('/:id')
.get(customersController.getCustomersByID)
.patch(customersController.patchCustomersById)
.delete(customersController.deleteCustomersByID);
module.exports = router;