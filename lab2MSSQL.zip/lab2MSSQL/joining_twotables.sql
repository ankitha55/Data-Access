use AdventureWorks;
SELECT x.ProductID,x.Name,x.ListPrice,
y.ProductCategoryID,y.Name,y.ModifiedDate
from SalesLT.Product x 
join SalesLT.ProductCategory y 
on x.ProductCategoryID=y.ProductCategoryID
