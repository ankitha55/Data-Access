SELECT * FROM SalesLT.Customer 
WHERE CustomerID=1;